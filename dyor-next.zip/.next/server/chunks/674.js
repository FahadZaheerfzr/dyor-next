"use strict";
exports.id = 674;
exports.ids = [674];
exports.modules = {

/***/ 5674:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BaseLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_simple_modal_provider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(718);
/* harmony import */ var react_simple_modal_provider__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_simple_modal_provider__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Footer_Footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(61);
/* harmony import */ var _Header_Header__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(852);
/* harmony import */ var _Modals_NewProject__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6456);
/* harmony import */ var _Modals_WalletModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6420);
/* harmony import */ var _Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2878);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Modals_NewProject__WEBPACK_IMPORTED_MODULE_6__]);
_Modals_NewProject__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









function BaseLayout({ children , title , footer  }) {
    const [sideBar, setSideBar] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const handleSideBar = ()=>{
        setSideBar(!sideBar);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_simple_modal_provider__WEBPACK_IMPORTED_MODULE_3__.ModalProvider, {
        value: [
            _Modals_WalletModal__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
            _Modals_NewProject__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z
        ],
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: title
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex w-full bg-lightWhite dark:bg-fields ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "hidden md:block md:w-[250px] fixed h-screen z-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            handleSideBar: handleSideBar,
                            toggleSidebar: handleSideBar
                        })
                    }),
                    sideBar && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "md:hidden dark:bg-primary w-[250px] h-screen fixed top-0 z-50",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            handleSideBar: handleSideBar,
                            toggleSidebar: handleSideBar
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `w-full pr-2 flex flex-col ${footer ? "justify-between" : ""} min-h-screen md:pl-10 ease-in-out md:z-50 md:pr-0 md:mr-10 md:ml-[60px] bg-lightWhite dark:bg-fields relative duration-300 ${sideBar ? "md:translate-x-[200px] md:!w-[calc(100%-300px)] md:mr-20" : ""}`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header_Header__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                toggleSidebar: handleSideBar
                            }),
                            children,
                            footer && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer_Footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                        ]
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 61:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function Footer() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
        className: "mt-auto flex",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "footer flex items-center text-sm border-t border-[#D6D3D1] dark:border-muted w-full justify-between mt-10 py-5 text-muted",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "uppercase font-semibold",
                    children: "\xa9 2022 DYOR"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
                    className: "text-gold flex gap-x-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            href: "mailto:info@dogeyourownresearch.com",
                            target: "_blank",
                            rel: "noreferrer",
                            children: "Support"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "divider text-[#44403C]",
                            children: "|"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            href: "https://docs.dogeyourownresearch.com/",
                            target: "_blank",
                            rel: "noreferrer",
                            children: "Whitepaper"
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 852:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./utils/formatAddress.js
const formatAddress = (address)=>{
    return `${address.substring(0, 6)}...${address.substring(39, 42)}`.toLowerCase();
};

// EXTERNAL MODULE: external "@usedapp/core"
var core_ = __webpack_require__(9439);
// EXTERNAL MODULE: external "next-themes"
var external_next_themes_ = __webpack_require__(1162);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-simple-modal-provider"
var external_react_simple_modal_provider_ = __webpack_require__(718);
;// CONCATENATED MODULE: ./components/Header/Header.js







function Header({ toggleSidebar  }) {
    const { account  } = (0,core_.useEthers)();
    const { theme , setTheme  } = (0,external_next_themes_.useTheme)();
    const [tempfixed, setTempFixed] = external_react_default().useState(false);
    const { open: openModal  } = (0,external_react_simple_modal_provider_.useModal)("ConnectionModal");
    (0,external_react_.useEffect)(()=>{
        if (theme === "dark") {
            setTempFixed(false);
        } else {
            setTempFixed(true);
        }
    }, [
        theme
    ]);
    const handleTempFixed = ()=>{
        setTempFixed(!tempfixed);
        setTheme(theme === "dark" ? "light" : "dark");
    };
    const handleOpen = ()=>{
        if (!account) {
            openModal();
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        className: "flex justify-between md:justify-end pt-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "md:hidden pl-5",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "w-full h-[60px]",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        onClick: toggleSidebar,
                        className: "flex cursor-pointer flex-row items-center h-full justify-start",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            width: 30,
                            height: 30,
                            src: "/images/sidebar/side1.png",
                            alt: "sidebar-item-icon"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                        htmlFor: "default-toggle",
                        className: "inline-flex relative items-center cursor-pointer mr-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "checkbox",
                                value: "",
                                checked: tempfixed ? false : true,
                                id: "default-toggle",
                                className: "sr-only peer",
                                onChange: handleTempFixed
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `w-10 h-6 bg-transparent peer-focus:outline-none peer-focus:ring-0 peer-focus:ring-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-gold after:content-[''] after:absolute after:top-[22px] ${account ? "after:md:top-[4px]" : "after:md:top-[12px]"} after:left-[2px] peer-checked:after:left-[6px] after:bg-gold after:border-gold after:border after:rounded-full after:h-4 after:w-4 after:transition-all border border-gold`
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "cursor-pointer",
                        onClick: handleOpen,
                        children: account ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "py-[9px] font-nunito_sans px-4 border border-gold rounded-xl text-gold font-light",
                            children: formatAddress(account)
                        }) : !tempfixed ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: "brand-image",
                            src: "/images/wallet.svg",
                            alt: "logo",
                            width: 40,
                            height: 40
                        }) : /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: "brand-image",
                            src: "/images/wallet-light.svg",
                            alt: "logo",
                            width: 40,
                            height: 40
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 6456:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ OpenProject)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _usedapp_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9439);
/* harmony import */ var _usedapp_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_usedapp_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_simple_modal_provider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(718);
/* harmony import */ var react_simple_modal_provider__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_simple_modal_provider__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function OpenProject({ children  }) {
    const [isOpen, setOpen] = (0,react_simple_modal_provider__WEBPACK_IMPORTED_MODULE_4__.useModalState)();
    const { account  } = (0,_usedapp_core__WEBPACK_IMPORTED_MODULE_1__.useEthers)();
    const [new_contract_address, setNewContractAddress] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const openNewProject = async ()=>{
        if (account) {
            try {
                const response = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].post("/api/fetch_developer", {
                    developer_wallet: account
                });
                if (response.data.length === 0) {
                    console.log("No developer found");
                } else {
                    let developer = response.data[0];
                    await axios__WEBPACK_IMPORTED_MODULE_2__["default"].post("/api/new_project", {
                        previous_contract_address: developer.contract_address,
                        new_contract_address: new_contract_address
                    });
                }
                setOpen(false);
            } catch (error) {
                alert("Something went wrong");
            }
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_simple_modal_provider__WEBPACK_IMPORTED_MODULE_4___default()), {
        id: "OpenProject",
        consumer: children,
        isOpen: isOpen,
        setOpen: setOpen,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "p-9 w-full max-w-[520px] font-nunito_sans bg-white dark:bg-fields text-muted rounded-[10px] mx-auto",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-between items-center ",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-semibold text-lg",
                            children: "Open a new Project"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center cursor-pointer ml-20",
                            onClick: ()=>setOpen(false),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-sm font-gilroy font-semibold text-dark-text dark:text-light-text mr-2",
                                    children: "Close"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex justify-center items-center bg-[#E56060] text-[#E56060] bg-opacity-10 rounded-full w-[15px] h-[15px]",
                                    children: "✕"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-8",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            children: [
                                "Contract Address",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-red-600",
                                    children: "\xa0 *"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "text",
                            className: "w-full mt-2 p-2 rounded-[10px] border border-gray-300 dark:border-gray-700 bg-lightWhite dark:bg-fields focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent",
                            placeholder: "Contract Address",
                            onChange: (e)=>setNewContractAddress(e.target.value)
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-8",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "w-full py-2 rounded-[10px] bg-gold text-white font-semibold",
                        onClick: openNewProject,
                        children: "Open Project"
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6420:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ConnectionModal)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-simple-modal-provider"
var external_react_simple_modal_provider_ = __webpack_require__(718);
var external_react_simple_modal_provider_default = /*#__PURE__*/__webpack_require__.n(external_react_simple_modal_provider_);
// EXTERNAL MODULE: external "@walletconnect/web3-provider/dist/umd/index.min.js"
var index_min_js_ = __webpack_require__(5579);
var index_min_js_default = /*#__PURE__*/__webpack_require__.n(index_min_js_);
// EXTERNAL MODULE: external "@usedapp/core"
var core_ = __webpack_require__(9439);
;// CONCATENATED MODULE: ./data/wallets.js
const wallets = [
    {
        id: 1,
        name: "Metamask",
        image: "/images/wallets/metamask.svg"
    },
    {
        id: 2,
        name: "WalletConnect",
        image: "/images/wallets/wallet_connect.svg"
    }
];

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./config/networks.js
var networks = __webpack_require__(8988);
;// CONCATENATED MODULE: ./components/Modals/WalletModal.js








function ConnectionModal({ children  }) {
    const [isOpen, setOpen] = (0,external_react_simple_modal_provider_.useModalState)();
    const { activate , account , activateBrowserWallet  } = (0,core_.useEthers)();
    const onConnect = async ()=>{
        try {
            const provider = new (index_min_js_default())({
                rpc: networks/* networkConfig.readOnlyUrls */.$.readOnlyUrls
            });
            await provider.enable();
            await activate(provider);
        } catch (error) {
            console.error(error);
        }
    };
    const onMetamask = async ()=>{
        try {
            activateBrowserWallet();
        } catch (error) {
            console.error(error);
        }
    };
    (0,external_react_.useEffect)(()=>{
        if (account) {
            setOpen(false);
        }
    }, [
        account,
        setOpen
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx((external_react_simple_modal_provider_default()), {
        id: "ConnectionModal",
        consumer: children,
        isOpen: isOpen,
        setOpen: setOpen,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "p-9 w-[90%] max-w-[520px] bg-white dark:bg-fields text-muted rounded-[10px] mx-auto",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex justify-between items-center ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "text-dark-text dark:text-light-text font-gilroy font-semibold text-lg",
                            children: "Connect Wallet"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex items-center cursor-pointer",
                            onClick: ()=>setOpen(false),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-sm font-gilroy font-semibold text-dark-text dark:text-light-text mr-2",
                                    children: "Close"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex justify-center items-center bg-[#E56060] text-[#E56060] bg-opacity-10 rounded-full w-[15px] h-[15px]",
                                    children: "✕"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mt-14 grid grid-cols-2 gap-8",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            className: "flex focus:outline-none focus:outline-gold py-4 px-4 flex-col items-center justify-center",
                            onClick: onMetamask,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: wallets[0].image,
                                    alt: wallets[0].name,
                                    width: 50,
                                    height: 50,
                                    className: "mb-4"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "font-gilroy font-semibold text-dark-text dark:text-light-text",
                                    children: wallets[0].name
                                })
                            ]
                        }, wallets[0].id),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            className: "flex focus:outline-none focus:outline-gold active:outline-none py-4 px-4 flex-col items-center justify-center",
                            onClick: onConnect,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: wallets[1].image,
                                    alt: wallets[1].name,
                                    width: 50,
                                    height: 50,
                                    className: "mb-4"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "font-gilroy font-semibold text-dark-text dark:text-light-text",
                                    children: wallets[1].name
                                })
                            ]
                        }, wallets[1].id)
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-center mt-12",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-gray dark:text-gray-dark font-semibold font-gilroy",
                        children: "Haven’t got a crypto wallet yet?"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-center mt-5",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-primary-green font-semibold font-gilroy",
                        children: "Learn how to connect"
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 2878:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Sidebar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/BaseLogo/BaseLogo.js



function BaseLogo() {
    return /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
        className: "brand-image",
        src: "/images/logo.svg",
        alt: "logo",
        width: 40,
        height: 40
    });
}

;// CONCATENATED MODULE: ./components/Sidebar/Sidebar.js





function Sidebar({ handleSideBar , toggleSidebar  }) {
    const [openSub1, setOpenSub1] = (0,external_react_.useState)(false);
    const [openSub2, setOpenSub2] = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        if (handleSideBar) {
            setOpenSub1(false);
            setOpenSub2(false);
        }
    }, [
        handleSideBar
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "h-screen w-full overflow-y-scroll font-nunito_sans bg-white dark:bg-primary",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full flex justify-start ml-2 items-center my-5 mt-10",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "brand",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(BaseLogo, {})
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "menu-items ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full h-[60px] pl-5",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            onClick: toggleSidebar,
                            className: "flex cursor-pointer flex-row items-center h-full justify-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    width: 20,
                                    height: 20,
                                    src: "/images/sidebar/side1.png",
                                    alt: "sidebar-item-icon"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "font-extrabold text-[#57534E] text-base ml-5",
                                    children: "Menu"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full h-[60px] pl-5",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "/",
                            className: "flex flex-row items-center h-full justify-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    width: 20,
                                    height: 20,
                                    src: "/images/sidebar/side2.png",
                                    alt: "sidebar-item-icon"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "font-extrabold text-[#57534E] text-base ml-5",
                                    children: "Home"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full h-[60px] pl-5",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row items-center h-full justify-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/developers/registration",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        width: 20,
                                        height: 20,
                                        src: "/images/sidebar/side3.png",
                                        alt: "sidebar-item-icon"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex items-center cursor-pointer",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "font-extrabold text-[#57534E] text-base ml-5 flex flex-row items-center",
                                        onClick: ()=>setOpenSub1(!openSub1),
                                        children: [
                                            "Developers",
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                width: "11",
                                                height: "6",
                                                viewBox: "0 0 11 6",
                                                className: `ml-5 dark:fill-[#57534E] ease-in-out duration-200 ${openSub1 ? "" : "rotate-180"}`,
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M0.371299 5.67718C0.471681 5.77952 0.590872 5.86071 0.72206 5.9161C0.853249 5.97149 0.993864 6 1.13587 6C1.27788 6 1.41849 5.97149 1.54968 5.9161C1.68087 5.86071 1.80006 5.77952 1.90044 5.67718L5.20518 2.31078C5.27275 2.24195 5.36438 2.20329 5.45992 2.20329C5.55546 2.20329 5.64709 2.24195 5.71466 2.31078L9.01867 5.67718C9.22135 5.88378 9.49629 5.99989 9.78299 5.99996C10.0697 6.00003 10.3447 5.88405 10.5475 5.67755C10.7502 5.47104 10.8642 5.19091 10.8643 4.8988C10.8643 4.60668 10.7505 4.3265 10.5478 4.1199L7.24308 0.752762C7.00887 0.514108 6.73082 0.324797 6.4248 0.195637C6.11878 0.0664778 5.79079 -4.51356e-07 5.45956 -4.80824e-07C5.12832 -5.10292e-07 4.80033 0.0664777 4.49431 0.195637C4.18829 0.324797 3.91024 0.514108 3.67604 0.752761L0.371299 4.1199C0.168657 4.32643 0.0548192 4.6065 0.0548192 4.89854C0.0548192 5.19057 0.168657 5.47065 0.371299 5.67718Z"
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    openSub1 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg-fields bg-opacity-10 pl-8",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full h-[60px] sidebarsub",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/developers/registration",
                                    className: "flex flex-row items-center h-full justify-start",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-extrabold text-[#57534E] text-base ml-[35px]",
                                        children: "Registration"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full h-[60px]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    onClick: ()=>setOpenSub2(!openSub2),
                                    className: `flex flex-row cursor-pointer items-center h-full justify-start `,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "font-extrabold text-[#57534E] text-base ml-[35px] flex flex-row items-center",
                                        children: [
                                            "Charts",
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                width: "11",
                                                height: "6",
                                                viewBox: "0 0 11 6",
                                                className: `ml-5 dark:fill-[#57534E] ease-in-out duration-200 ${openSub2 ? "" : "rotate-180"}`,
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M0.371299 5.67718C0.471681 5.77952 0.590872 5.86071 0.72206 5.9161C0.853249 5.97149 0.993864 6 1.13587 6C1.27788 6 1.41849 5.97149 1.54968 5.9161C1.68087 5.86071 1.80006 5.77952 1.90044 5.67718L5.20518 2.31078C5.27275 2.24195 5.36438 2.20329 5.45992 2.20329C5.55546 2.20329 5.64709 2.24195 5.71466 2.31078L9.01867 5.67718C9.22135 5.88378 9.49629 5.99989 9.78299 5.99996C10.0697 6.00003 10.3447 5.88405 10.5475 5.67755C10.7502 5.47104 10.8642 5.19091 10.8643 4.8988C10.8643 4.60668 10.7505 4.3265 10.5478 4.1199L7.24308 0.752762C7.00887 0.514108 6.73082 0.324797 6.4248 0.195637C6.11878 0.0664778 5.79079 -4.51356e-07 5.45956 -4.80824e-07C5.12832 -5.10292e-07 4.80033 0.0664777 4.49431 0.195637C4.18829 0.324797 3.91024 0.514108 3.67604 0.752761L0.371299 4.1199C0.168657 4.32643 0.0548192 4.6065 0.0548192 4.89854C0.0548192 5.19057 0.168657 5.47065 0.371299 5.67718Z"
                                                })
                                            })
                                        ]
                                    })
                                })
                            }),
                            openSub2 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "w-full h-[60px] sidebarsub",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/developers/charts",
                                            className: "flex flex-row items-center h-full justify-start",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-extrabold text-[#57534E] text-base ml-[35px]",
                                                children: "Current Charts"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "w-full h-[60px] sidebarsub",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/developers/charts",
                                            className: "flex flex-row items-center h-full justify-start",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-extrabold text-[#57534E] text-base ml-[35px]",
                                                children: "Previous Charts"
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full h-[60px] sidebarsub",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/developers/overview",
                                    className: "flex flex-row items-center h-full justify-start",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-extrabold text-[#57534E] text-base ml-[35px]",
                                        children: "Developer Ranking"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full h-[60px] pl-5",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row items-center h-full justify-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/kyc_audit",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        width: 20,
                                        height: 20,
                                        src: "/images/sidebar/side4.png",
                                        alt: "sidebar-item-icon"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "font-extrabold text-[#57534E] text-base ml-5",
                                    children: "KYC & Audit"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full h-[60px] pl-5",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row items-center h-full justify-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/reviews",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        width: 20,
                                        height: 20,
                                        className: "h-[20px] w-[20px]",
                                        src: "/images/sidebar/side5.png",
                                        alt: "sidebar-item-icon"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "font-extrabold text-[#57534E] text-base ml-5",
                                    children: "Reviews"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full h-[60px] pl-5",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row items-center h-full justify-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/map",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        width: 20,
                                        height: 20,
                                        className: "h-[20px] w-[20px]",
                                        src: "/images/sidebar/side6.png",
                                        alt: "sidebar-item-icon"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "font-extrabold text-[#57534E] text-base ml-5",
                                    children: "Bubble Map"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full h-[60px] pl-5",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row items-center h-full justify-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    width: 20,
                                    height: 20,
                                    className: "h-[20px] w-[20px]",
                                    src: "/images/sidebar/side7.png",
                                    alt: "sidebar-item-icon"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "font-extrabold text-[#57534E] text-base ml-5",
                                    children: "Scan for scammer"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full h-[60px] pl-5",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row items-center h-full justify-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    width: 20,
                                    height: 20,
                                    className: "h-[20px] w-[20px]",
                                    src: "/images/sidebar/side8.png",
                                    alt: "sidebar-item-icon"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "font-extrabold text-[#57534E] text-base ml-5",
                                    children: "Buy Bot"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 8988:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ networkConfig)
/* harmony export */ });
/* harmony import */ var _usedapp_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9439);
/* harmony import */ var _usedapp_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_usedapp_core__WEBPACK_IMPORTED_MODULE_0__);
// import { BSC, BSCTestnet } from '@usedapp/core'

// import { RbaChain } from './constants/chain'
const networkConfig = {
    readOnlyChainId: _usedapp_core__WEBPACK_IMPORTED_MODULE_0__.Mainnet.chainId,
    autoConnect: true,
    readOnlyUrls: {
        //[BSCTestnet.chainId]: 'https://rpc.ankr.com/bsc_testnet_chapel',
        [_usedapp_core__WEBPACK_IMPORTED_MODULE_0__.Mainnet.chainId]: "https://rpc.ankr.com/bsc"
    },
    networks: [
        _usedapp_core__WEBPACK_IMPORTED_MODULE_0__.Mainnet
    ],
    noMetamaskDeactivate: true,
    refresh: "never",
    pollingInterval: 15000
};


/***/ })

};
;