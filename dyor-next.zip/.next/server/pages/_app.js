(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 8464:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Nunito_02433b', '__Nunito_Fallback_02433b'","fontStyle":"normal"},
	"className": "__className_02433b",
	"variable": "__variable_02433b"
};


/***/ }),

/***/ 8230:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Nunito_Sans_a053ac', '__Nunito_Sans_Fallback_a053ac'","fontStyle":"normal"},
	"className": "__className_a053ac",
	"variable": "__variable_a053ac"
};


/***/ }),

/***/ 8988:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ networkConfig)
/* harmony export */ });
/* harmony import */ var _usedapp_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9439);
/* harmony import */ var _usedapp_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_usedapp_core__WEBPACK_IMPORTED_MODULE_0__);
// import { BSC, BSCTestnet } from '@usedapp/core'

// import { RbaChain } from './constants/chain'
const networkConfig = {
    readOnlyChainId: _usedapp_core__WEBPACK_IMPORTED_MODULE_0__.Mainnet.chainId,
    autoConnect: true,
    readOnlyUrls: {
        //[BSCTestnet.chainId]: 'https://rpc.ankr.com/bsc_testnet_chapel',
        [_usedapp_core__WEBPACK_IMPORTED_MODULE_0__.Mainnet.chainId]: "https://rpc.ankr.com/bsc"
    },
    networks: [
        _usedapp_core__WEBPACK_IMPORTED_MODULE_0__.Mainnet
    ],
    noMetamaskDeactivate: true,
    refresh: "never",
    pollingInterval: 15000
};


/***/ }),

/***/ 9287:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"pages/_app.js","import":"Nunito_Sans","arguments":[{"variable":"--nunito-sans-font","subsets":["latin"],"weight":["200","300","400","600","700","800","900"]}],"variableName":"nunito_sans"}
var _app_js_import_Nunito_Sans_arguments_variable_nunito_sans_font_subsets_latin_weight_200_300_400_600_700_800_900_variableName_nunito_sans_ = __webpack_require__(8230);
var _app_js_import_Nunito_Sans_arguments_variable_nunito_sans_font_subsets_latin_weight_200_300_400_600_700_800_900_variableName_nunito_sans_default = /*#__PURE__*/__webpack_require__.n(_app_js_import_Nunito_Sans_arguments_variable_nunito_sans_font_subsets_latin_weight_200_300_400_600_700_800_900_variableName_nunito_sans_);
// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"pages/_app.js","import":"Nunito","arguments":[{"variable":"--nunito-font","subsets":["latin"],"weight":["200","300","400","600","700","800","900"]}],"variableName":"nunito"}
var _app_js_import_Nunito_arguments_variable_nunito_font_subsets_latin_weight_200_300_400_600_700_800_900_variableName_nunito_ = __webpack_require__(8464);
var _app_js_import_Nunito_arguments_variable_nunito_font_subsets_latin_weight_200_300_400_600_700_800_900_variableName_nunito_default = /*#__PURE__*/__webpack_require__.n(_app_js_import_Nunito_arguments_variable_nunito_font_subsets_latin_weight_200_300_400_600_700_800_900_variableName_nunito_);
;// CONCATENATED MODULE: external "styled-jsx/style"
const style_namespaceObject = require("styled-jsx/style");
var style_default = /*#__PURE__*/__webpack_require__.n(style_namespaceObject);
// EXTERNAL MODULE: ./config/networks.js
var networks = __webpack_require__(8988);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: external "@usedapp/core"
var core_ = __webpack_require__(9439);
// EXTERNAL MODULE: external "next-themes"
var external_next_themes_ = __webpack_require__(1162);
;// CONCATENATED MODULE: ./pages/_app.js








function App({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(core_.DAppProvider, {
        config: networks/* networkConfig */.$,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_next_themes_.ThemeProvider, {
            attribute: "class",
            defaultTheme: "dark",
            children: [
                jsx_runtime_.jsx((style_default()), {
                    id: "24cdfae12f2995e3",
                    dynamic: [
                        (_app_js_import_Nunito_arguments_variable_nunito_font_subsets_latin_weight_200_300_400_600_700_800_900_variableName_nunito_default()).style.fontFamily,
                        (_app_js_import_Nunito_Sans_arguments_variable_nunito_sans_font_subsets_latin_weight_200_300_400_600_700_800_900_variableName_nunito_sans_default()).style.fontFamily
                    ],
                    children: `:root{--nunito-font:${(_app_js_import_Nunito_arguments_variable_nunito_font_subsets_latin_weight_200_300_400_600_700_800_900_variableName_nunito_default()).style.fontFamily};--nunito-sans-font:${(_app_js_import_Nunito_Sans_arguments_variable_nunito_sans_font_subsets_latin_weight_200_300_400_600_700_800_900_variableName_nunito_sans_default()).style.fontFamily}}`
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps,
                    className: style_default().dynamic([
                        [
                            "24cdfae12f2995e3",
                            [
                                (_app_js_import_Nunito_arguments_variable_nunito_font_subsets_latin_weight_200_300_400_600_700_800_900_variableName_nunito_default()).style.fontFamily,
                                (_app_js_import_Nunito_Sans_arguments_variable_nunito_sans_font_subsets_latin_weight_200_300_400_600_700_800_900_variableName_nunito_sans_default()).style.fontFamily
                            ]
                        ]
                    ]) + " " + (pageProps && pageProps.className != null && pageProps.className || "")
                })
            ]
        })
    });
}


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 9439:
/***/ ((module) => {

"use strict";
module.exports = require("@usedapp/core");

/***/ }),

/***/ 1162:
/***/ ((module) => {

"use strict";
module.exports = require("next-themes");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9287));
module.exports = __webpack_exports__;

})();