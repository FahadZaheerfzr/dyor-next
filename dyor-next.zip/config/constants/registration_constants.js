export const registrationFee = 100000000;


